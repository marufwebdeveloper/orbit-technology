<?php

/**
 * Plugin Name: Team Member
 * Plugin URI: 
 * Description: Team Member
 * Version: 1.0.0
 */



add_action( 'wp_enqueue_scripts', function(){
	wp_enqueue_style( 'team-member-style', plugins_url( 'assets/css/style.css', __FILE__ ) );
});

add_action( 'init',function() {
    register_post_type( 'team-member',
        array(
        	'menu_icon' => 'dashicons-businessperson',
            'labels' => array(
                'name' => __( 'Team Members' ),
                'singular_name' => __( 'Team Members' ),
                'add_new_item' => __('Add Team Member', 'txtdomain'),
				'new_item' => __('New team member', 'txtdomain'),
				'view_item' => __('View team member', 'txtdomain'),
				'not_found' => __('No team members found', 'txtdomain'),
				'not_found_in_trash' => __('No team members found in trash', 'txtdomain'),
				'all_items' => __('All team members', 'txtdomain'),
				'insert_into_item' => __('Insert into team member', 'txtdomain')
	        ),
            'has_archive' => true,
            'supports' => ['title', 'editor', 'thumbnail', 'author'],
            'public' => true,
            'rewrite' => array('slug' => 'team-member')
        )
    );
    register_taxonomy('member-type', ['team-member'], [
		'hierarchical' => true,
		'rewrite' => ['slug' => 'team-member-type'],
		'show_admin_column' => true,
		'show_in_rest' => true,
		'labels' => [
			'name' => __('Member Type', 'txtdomain'),
			'singular_name' => __('Member Type', 'txtdomain'),
			'all_items' => __('All Member Type', 'txtdomain'),
			'edit_item' => __('Edit Member Type', 'txtdomain'),
			'view_item' => __('View Member Type', 'txtdomain'),
			'update_item' => __('Update Member Type', 'txtdomain'),
			'add_new_item' => __('Add New Member Type', 'txtdomain'),
			'new_item_name' => __('New Member Type Name', 'txtdomain'),
			'search_items' => __('Search Member Types', 'txtdomain'),
			'popular_items' => __('Popular Member Types', 'txtdomain'),
			'separate_items_with_commas' => __('Separate authors with comma', 'txtdomain'),
			'choose_from_most_used' => __('Choose from most used authors', 'txtdomain'),
			'not_found' => __('No Authors found', 'txtdomain'),
		]
	]);

	 
});

add_action( 'admin_menu', function(){
	add_submenu_page(
        'edit.php?post_type=team-member',
        __('Settings', 'txtdomain'),
        __('Settings', 'txtdomain'),
        'manage_options',
        'team-member-settings',
        function(){
        	require_once dirname(__FILE__) .'/settings-team-member.php';
        });
} );


add_action( 'edit_form_after_title', function() {
	$screen = get_current_screen();
	if  ( 'team-member' == $screen->post_type ) {
          echo '<h1>Bio : </h1>';
     } 
	
});
   
add_filter( 'enter_title_here', function ( $title ){
     $screen = get_current_screen();
   
     if  ( 'team-member' == $screen->post_type ) {
          $title = 'Enter Member Name';
     }   
     return $title;
});

add_action( 'add_meta_boxes', function() {
    add_meta_box( 'team_member_position', 'Position / Designation', function($post){
    	$meta_val = get_post_meta( $post->ID, 'team-member-position', true );
    	echo "<input type='text' name='team-member-position' value='".esc_attr( $meta_val )."' placeholder='Enter Member Position/Designation' style='width:100%'/>";
    }, 'team-member', 'normal' ,'high');
} );
 

add_action( 'save_post', function( $post_id ) {
    if ( isset( $_POST['team-member-position'] ) ) {
        update_post_meta( $post_id, 'team-member-position', $_POST['team-member-position'] );
    }
} );



add_filter( 'single_template', function ( $single_template ){
    global $post;
    if($post->post_type == 'team-member'){
    	$file = dirname(__FILE__) .'/single-'. $post->post_type .'.php';
    	if( file_exists( $file ) ) $single_template = $file;
    }
    return $single_template;
} );

add_filter( 'archive_template', function ( $single_template ){
    global $post;
    if($post->post_type == 'team-member'){
    	$file = dirname(__FILE__) .'/archive-'. $post->post_type .'.php';
    	if( file_exists( $file ) ) $single_template = $file;
    }
    return $single_template;
} );



add_shortcode( 'team_members', function( $atts = '' ) {
    $params = shortcode_atts( array(
        'number_of_member' => '',
        'image_position' => '', // top,bottom
        'view_more_button' =>'' // show/hide
    ), $atts );

	ob_start();
	require_once dirname(__FILE__) .'/short-code-team-member.php';
	$output = ob_get_contents();
	ob_end_clean();

    return $output;
});


